using UnityEngine;

public class GroundScroller : MonoBehaviour
{
    public float speed = 2.0f;  // Speed at which the houses move
    public GameObject[] houses;  // Array to hold house prefabs
    private float houseWidth;     // Width of one house (for repositioning)
    //public float gap = 0.0f;      // Gap between houses

    private int housesCount; // Count of houses in the array

    void Start()
    {
        // Get the width of one house sprite
        houseWidth = houses[0].GetComponent<SpriteRenderer>().bounds.size.x;

        // Set initial positions of the houses
        SetInitialPositions();
        housesCount = houses.Length; // Store the number of houses
    }

    void Update()
    {
        // Move all houses to the left
        for (int i = 0; i < housesCount; i++)
        {
            houses[i].transform.Translate(Vector2.left * speed * Time.deltaTime);

            // Check if the left edge of the first two houses is completely off-screen
            if (houses[0].transform.position.x < -houseWidth && houses[1].transform.position.x < -houseWidth)
            {
                // Reposition the first house to the right of the last house
                houses[0].transform.position = new Vector2(
                    houses[housesCount - 1].transform.position.x + houseWidth,
                    houses[0].transform.position.y);

                // Swap houses: the first house becomes the last
                SwapHouses();
            }
        }
    }

    private void SetInitialPositions()
    {
        // Set the initial positions of the houses with equal gaps
        for (int i = 0; i < housesCount; i++)
        {
            float initialX = (houseWidth) * i;
            houses[i].transform.position = new Vector2(initialX, houses[i].transform.position.y);
        }
    }

    private void SwapHouses()
    {
        // Move the houses forward in the array
        GameObject temp = houses[0];
        for (int i = 0; i < housesCount - 1; i++)
        {
            houses[i] = houses[i + 1];
        }
        houses[housesCount - 1] = temp; // Place the first house at the end of the array
    }
}
