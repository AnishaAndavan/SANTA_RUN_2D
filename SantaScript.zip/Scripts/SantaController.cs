using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SantaController : MonoBehaviour
{
    public Sprite[] runningSprites;    // Array to hold the running sprites of Santa
    public Sprite[] jumpingSprites;    // Array to hold the jumping sprites of Santa
    public float frameRate = 0.1f;     // Time between frame changes (speed of animation)
    public float jumpForce = 5f;       // Force applied to make Santa jump
    public float fallDelay = 2f;       // Time Santa stays in the air before coming down
    public KeyCode jumpKey = KeyCode.Space; // The key to trigger a jump
    public Vector2 defaultPosition;    // Default position to reset after jumping
    public float jumpHeight = 2f;      // The maximum height that Santa can reach (editable)

    private SpriteRenderer spriteRenderer;  // To display the sprite on the screen
    private Rigidbody2D rb;                // To handle the physics for jumping
    private int currentFrame;              // To track the current frame of animation
    private float timer;                   // Timer to control animation speed
    private bool isJumping = false;        // To track whether Santa is jumping
    private bool isGrounded = true;        // To check if Santa is on the ground

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        currentFrame = 0;
        spriteRenderer.sprite = runningSprites[currentFrame];
        defaultPosition = transform.position;
    }

    void Update()
    {
        if (Input.GetKeyDown(jumpKey) && isGrounded)
        {
            Jump();
        }

        if (isJumping)
        {
            AnimateJump();
        }
        else
        {
            AnimateRun();
        }
    }

    void Jump()
    {
        rb.velocity = new Vector2(rb.velocity.x, jumpForce * jumpHeight);
        isJumping = true;
        isGrounded = false;
        currentFrame = 0;
        spriteRenderer.sprite = jumpingSprites[currentFrame];
        StartCoroutine(ResetAfterJump());
    }

    IEnumerator ResetAfterJump()
    {
        yield return new WaitForSeconds(fallDelay);
        rb.velocity = Vector2.zero;
        transform.position = new Vector2(transform.position.x, defaultPosition.y);
        isGrounded = true;
        isJumping = false;
        currentFrame = 0;
        spriteRenderer.sprite = runningSprites[currentFrame];
    }

    void AnimateRun()
    {
        timer += Time.deltaTime;
        if (timer >= frameRate)
        {
            currentFrame = (currentFrame + 1) % runningSprites.Length;
            spriteRenderer.sprite = runningSprites[currentFrame];
            timer = 0f;
        }
    }

    void AnimateJump()
    {
        timer += Time.deltaTime;
        if (timer >= frameRate)
        {
            currentFrame = (currentFrame + 1) % jumpingSprites.Length;
            spriteRenderer.sprite = jumpingSprites[currentFrame];
            timer = 0f;
        }
    }

    // Detect collision with Chimney
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
            isJumping = false;
            currentFrame = 0;
            spriteRenderer.sprite = runningSprites[currentFrame];
        }

        // Check if Santa collides with the chimney
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            // Trigger the game over transition
            StartCoroutine(GoToGameOverScene());
        }
    }

    // Coroutine to handle scene transition
    IEnumerator GoToGameOverScene()
    {
        // Optional delay for smoother transition
        yield return new WaitForSeconds(0.5f);

        // Play your transition animation (e.g., sliding, dropping effect)
        SceneManager.LoadScene("GameOverScene", LoadSceneMode.Single);
    }
}
