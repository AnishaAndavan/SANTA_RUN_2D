using UnityEngine;

public class ExitGame: MonoBehaviour
{
    // This method is called when the mouse clicks on the collider attached to the sprite
    private void OnMouseDown()
    {
        // Exit the game (this only works in a build, not in the Unity editor)
        Exit();
    }
    public void Exit()
    {
        Application.Quit();
    }
}
