using UnityEngine;
using UnityEngine.SceneManagement; // Required to load scenes

public class PlayButton : MonoBehaviour
{
    // Detect mouse click on the sprite
    private void OnMouseDown()
    {
        // Load the game scene when the "Play" sprite is clicked
        SceneManager.LoadScene("MainScene"); // Replace "GameScene" with the actual scene name
    }
}
