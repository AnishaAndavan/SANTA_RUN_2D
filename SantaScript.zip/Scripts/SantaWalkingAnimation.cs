using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SantaWalkingAnimation : MonoBehaviour
{
    public Sprite[] santaSprites;  // Array to hold the 13 walking images of Santa
    public float frameRate = 0.1f; // Time between frame changes (speed of animation)
    public float speed = 2.0f;     // Santa's movement speed
    public float startXPosition = -10f; // The left side of the screen (off-screen)
    public float endXPosition = 10f;    // The right side of the screen (off-screen)

    private SpriteRenderer spriteRenderer; // To display the sprite on the screen
    private int currentFrame;              // To track the current frame of animation
    private float timer;                   // Timer to control animation speed
    private Vector3 santaPosition;         // To track and update Santa's position

    void Start()
    {
        // Get the SpriteRenderer component attached to the GameObject
        spriteRenderer = GetComponent<SpriteRenderer>();

        // Set Santa's initial position to the left side of the screen
        santaPosition = new Vector3(startXPosition, transform.position.y, transform.position.z);
        transform.position = santaPosition;

        // Start the animation at the first frame
        currentFrame = 0;
        spriteRenderer.sprite = santaSprites[currentFrame];
    }

    void Update()
    {
        // Update the animation
        AnimateSanta();

        // Move Santa to the right
        santaPosition.x += speed * Time.deltaTime;
        transform.position = santaPosition;

        // If Santa reaches the right end of the screen
        if (santaPosition.x >= endXPosition)
        {
            // Set Santa's position back to the left side of the screen
            santaPosition.x = startXPosition;
            transform.position = santaPosition;

            // Reset to the first frame of animation
            currentFrame = 0;
        }
    }

    void AnimateSanta()
    {
        // Increment the timer based on the frame rate
        timer += Time.deltaTime;

        // Change the frame when the timer exceeds the frame rate
        if (timer >= frameRate)
        {
            // Advance to the next frame
            currentFrame = (currentFrame + 1) % santaSprites.Length;

            // Update the sprite to the current frame
            spriteRenderer.sprite = santaSprites[currentFrame];

            // Reset the timer
            timer = 0f;
        }
    }
}
